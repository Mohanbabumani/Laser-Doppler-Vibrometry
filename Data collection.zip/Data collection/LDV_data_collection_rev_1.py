import sys, os, csv, time
from datetime import datetime

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from scipy.interpolate import interp1d

import nidaqmx
from nidaqmx.constants import AcquisitionType

import clr
from System.Text import StringBuilder

import pyvisa

# -----------------------------------------------------------------------------
# -------------------- MOTION PROFILE (TRAPEZOIDAL) ---------------------------
# -----------------------------------------------------------------------------
def trapezoidal_profile(t, D, a, v):
    t = np.array(t)
    t_a = v / a
    d_a = 0.5 * a * t_a**2
    # total move time
    if D > 2*d_a:
        T = 2*t_a + (D - 2*d_a)/v
    else:
        T = 2*np.sqrt(D/a)
    x = np.zeros_like(t)
    # acceleration phase
    mask_a = t < t_a
    x[mask_a] = 0.5*a*t[mask_a]**2
    # constant velocity phase
    mask_c = (t >= t_a) & (t <= T - t_a)
    x[mask_c] = d_a + v*(t[mask_c] - t_a)
    # deceleration phase
    mask_d = t > (T - t_a)
    t_dec = t[mask_d] - (T - t_a)
    x[mask_d] = d_a + v*(T - 2*t_a) + v*t_dec - 0.5*a*t_dec**2
    return np.minimum(x, D)

# -----------------------------------------------------------------------------
# ----------------------------- XPS CONTROLLER -------------------------------
# -----------------------------------------------------------------------------
# 1) Load the Newport XPS .NET assembly
clr.AddReference(
    r"C:\Windows\Microsoft.NET\assembly\GAC_64\Newport.XPS.CommandInterface"
    r"\v4.0_2.3.1.0__9a267756cf640dcf\Newport.XPS.CommandInterface.dll"
)
from CommandInterfaceXPS import XPS

# Connection & timeout
XPS_IP      = "192.168.0.254"
XPS_PORT    = 5001
XPS_TIMEOUT = 60000  # ms

# Axis groups
GROUP_X = "Group1"   # fast sweep
GROUP_Y = "Group2"   # slow line index

# Scan extents (mm)
X_START, X_END, X_STEP = 0.0, 10.0, 0.5
Y_START, Y_END, Y_STEP = 0.0,  5.0, 0.5

# Velocity & acceleration (mm/s, mm/s²)
VEL_X, ACC_X = 2.0, 5.0
VEL_Y, ACC_Y = 2.0, 5.0

# Choice of fast‐axis sweep
# 'X' = sweep X at each Y row; 'Y' = sweep Y at each X column
SCAN_AXIS = 'X'


def to_rc(ret):
    return ret if isinstance(ret, int) else ret[0]

def check(rc, name):
    if rc != 0:
        raise RuntimeError(f"{name} failed (code={rc})")

def wait_status(group, desired, timeout_s=30.0):
    t0 = time.time()
    while True:
        ret = xps.GroupStatusGet(group)
        rc, status = to_rc(ret), ret[1]
        check(rc, f"GroupStatusGet {group}")
        if status == desired:
            return
        if time.time() - t0 > timeout_s:
            raise TimeoutError(f"{group} did not reach status {desired}")
        time.sleep(0.02)

def home_axis(group, vel, acc):
    print(f"Homing {group}…")
    check(to_rc(xps.GroupInitialize(group)), f"GroupInitialize {group}")
    full = f"{group}.Pos"
    check(to_rc(xps.PositionerSGammaParametersSet(full, vel, acc, 0.001, 0.005)),
          f"PositionerSGammaParametersSet {full}")
    check(to_rc(xps.GroupHomeSearch(group)), f"GroupHomeSearch {group}")
    wait_status(group, 11)
    print(f"{group} homed.")

def set_profile(group, vel, acc):
    full = f"{group}.Pos"
    check(to_rc(xps.PositionerSGammaParametersSet(full, vel, acc, 0.001, 0.005)),
          f"PositionerSGammaParametersSet {full}")

def move_absolute(group, target):
    """Move `group` to absolute position `target` (mm) and wait."""
    check(to_rc(xps.GroupMoveAbsolute(group, [target], 1)),
          f"GroupMoveAbsolute {group}→{target}")
    wait_status(group, 12)

# -----------------------------------------------------------------------------
# ------------------------- VNA & DAQ SETUP ------------------------------------
# -----------------------------------------------------------------------------
def initialize_vna():
    rm = pyvisa.ResourceManager()
    vna = rm.open_resource(
        'TCPIP0::Eichenfield_LDV::hislip_PXI0_CHASSIS1_SLOT1_INDEX0::INSTR'
    )
    vna.timeout = 1_000_000
    print("VNA ID:", vna.query("*IDN?"))
    return vna

def configure_vna(vna, frequency, rf_power, if_bandwidth, points):
    vna.write("SENS:SWE:TYPE CW")
    vna.write(f"SENS:FREQ:CW {frequency}")
    vna.write(f"SOUR:POW {rf_power}")
    vna.write(f"SENS:BAND {if_bandwidth}")
    vna.write(f"SENS:SWE:POIN {points}")
    vna.write("CALC:PAR:DEF 'Meas1', S11")
    vna.write("CALC:PAR:DEF 'Meas2', S21")
    vna.write("DISP:WIND:TRAC:Y:AUTO")

def parse_sdata(sdata):
    nums = list(map(float, sdata.split(',')))
    cmplx = [complex(nums[i], nums[i+1]) for i in range(0,len(nums),2)]
    return [(abs(c), np.angle(c,deg=True)) for c in cmplx]

def save_s2p(s11_data, s21_data, filename, frequency, points):
    s11 = parse_sdata(s11_data)
    s21 = parse_sdata(s21_data)
    with open(filename,'w') as f:
        f.write("! S2P Data\n# Hz S MA R 50\n")
        for (m11,p11),(m21,p21) in zip(s11,s21):
            f.write(f"{frequency} {m11} {p11} {m21} {p21} 1e-10 45 1e-10 45\n")

# -----------------------------------------------------------------------------
# ------------------------- SCAN & DATA COLLECTION -----------------------------
# -----------------------------------------------------------------------------
def run_raster_scan(folder, mode, sampling_rate, vna, vna_params):
    """
    folder: output directory
    mode: 'calibration' (one line, RF off) or 'measurement' (full grid, RF on)
    """
    os.makedirs(folder, exist_ok=True)

    # RF off for calibration
    if mode=='calibration' and vna:
        vna.write("SOUR:POW 0")

    # build line positions
    xs = np.arange(X_START, X_END+1e-6, X_STEP)
    ys = np.arange(Y_START, Y_END+1e-6, Y_STEP)

    perp_positions = ys if SCAN_AXIS=='X' else xs
    sweep_positions = xs if SCAN_AXIS=='X' else ys

    # only first line in calibration
    if mode=='calibration':
        perp_positions = perp_positions[:1]

    for idx, perp in enumerate(perp_positions):
        # move slow axis
        if SCAN_AXIS=='X':
            move_absolute(GROUP_Y, perp)
        else:
            move_absolute(GROUP_X, perp)

        for direction in ('forward','backward'):
            start_pt = sweep_positions[0] if direction=='forward' else sweep_positions[-1]
            end_pt   = sweep_positions[-1] if direction=='forward' else sweep_positions[0]

            ts = int(time.time()*1000)
            csv_name  = f"line_scan_y{idx}_{direction}_{mode}_{ts}.csv"
            s2p_name  = f"line_scan_y{idx}_{direction}_{mode}_{ts}.s2p"
            csv_path  = os.path.join(folder, csv_name)
            s2p_path  = os.path.join(folder, s2p_name)

            # DAQ setup
            with nidaqmx.Task() as task:
                task.ai_channels.add_ai_voltage_chan("Dev1Mod1/ai3")
                task.timing.cfg_samp_clk_timing(
                    sampling_rate, sample_mode=AcquisitionType.CONTINUOUS
                )
                times, volts = [], []
                t0 = time.time()
                task.start()

                # trigger VNA
                if vna:
                    vna.write("INIT:CONT OFF")
                    line_time = abs(end_pt - start_pt) / (VEL_X if SCAN_AXIS=='X' else VEL_Y)
                    vna.write(f"SENS:SWE:TIME {line_time}")
                    vna.write("INIT")

                # move fast axis
                move_absolute(GROUP_X if SCAN_AXIS=='X' else GROUP_Y, end_pt)

                # read until motion done
                grp = GROUP_X if SCAN_AXIS=='X' else GROUP_Y
                while True:
                    data = task.read(number_of_samples_per_channel=nidaqmx.constants.READ_ALL_AVAILABLE)
                    t = time.time() - t0
                    times.extend([t]*len(data))
                    volts.extend(data)
                    ret = xps.GroupStatusGet(grp)
                    if to_rc(ret)==0 and ret[1]==12:
                        break
                    time.sleep(0.01)
                task.stop()

                # fetch VNA
                if vna:
                    vna.query("*OPC?")
                    vna.write("CALC:PAR:SEL 'Meas1'")
                    s11 = vna.query("CALC:DATA? SDATA").strip()
                    vna.write("CALC:PAR:SEL 'Meas2'")
                    s21 = vna.query("CALC:DATA? SDATA").strip()
                    save_s2p(s11, s21, s2p_path, **vna_params)

            # save DAQ CSV
            with open(csv_path,'w',newline='') as f:
                w = csv.writer(f)
                w.writerow(["Time (s)","Voltage (V)"])
                w.writerows(zip(times, volts))

            print(f"{mode.title()} line y{idx} {direction} saved → {csv_name}, {s2p_name}")

    # RF on after calibration
    if mode=='calibration' and vna:
        vna.write(f"SOUR:POW {vna_params['rf_power']}")

# -----------------------------------------------------------------------------
# ---------------------------- PLOTTING FUNCTIONS ------------------------------
# -----------------------------------------------------------------------------
import re, glob

def _find_files(folder, pattern):
    return sorted(glob.glob(os.path.join(folder, pattern)))

def plot_daq_voltage_first_line(folder, direction, mode):
    pattern = f"line_scan_y0_{direction}_{mode}_*.csv"
    files = _find_files(folder, pattern)
    if not files: return
    df = pd.read_csv(files[0])
    t, v = df.iloc[:,0].values, df.iloc[:,1].values

    # Time plot
    plt.figure()
    plt.plot(t, v)
    plt.xlabel("Time (s)"); plt.ylabel("Voltage (V)")
    plt.title(f"DAQ Voltage vs Time (y=0, {direction}, {mode})")
    out = os.path.join(folder, f"daq_time_y0_{direction}_{mode}.png")
    plt.savefig(out, dpi=300); plt.close()
    print(f"Saved {out}")

    # Position plot
    D = abs(X_END - X_START)  # mm
    x_pos = trapezoidal_profile(t - t[0], D, ACC_X, VEL_X)*1000  # µm
    plt.figure()
    plt.plot(x_pos, v)
    plt.xlabel("X Position (µm)"); plt.ylabel("Voltage (V)")
    plt.title(f"DAQ Voltage vs X (y=0, {direction}, {mode})")
    out = os.path.join(folder, f"daq_position_y0_{direction}_{mode}.png")
    plt.savefig(out, dpi=300); plt.close()
    print(f"Saved {out}")

def plot_voltage_map_time(folder, direction, mode):
    pattern = f"line_scan_y*_ {direction}_{mode}_*.csv".replace("*_","*")
    files = _find_files(folder, pattern)
    if not files: return

    times_list, volts_list, y_list = [], [], []
    for fn in files:
        idx = int(re.search(r"y(\d+)_", fn).group(1))
        y_list.append((Y_START + idx*Y_STEP)*1000)  # µm
        df = pd.read_csv(fn)
        times_list.append(df.iloc[:,0].values)
        volts_list.append(df.iloc[:,1].values)

    t_min = min(arr[0] for arr in times_list)
    t_max = max(arr[-1] for arr in times_list)
    N = max(len(arr) for arr in times_list)
    t_uniform = np.linspace(t_min, t_max, N)

    Vmap = np.array([
        interp1d(t, v, bounds_error=False, fill_value=np.nan)(t_uniform)
        for t,v in zip(times_list, volts_list)
    ])
    T, Y = np.meshgrid(t_uniform, y_list)

    plt.figure(figsize=(8,6))
    plt.pcolormesh(T, Y, Vmap, shading='auto')
    plt.colorbar(label="Voltage (V)")
    plt.xlabel("Time (s)"); plt.ylabel("Y Position (µm)")
    plt.title(f"DAQ Voltage Map vs Time ({direction}, {mode})")
    out = os.path.join(folder, f"spatial_map_time_{direction}_{mode}.png")
    plt.savefig(out, dpi=300); plt.close()
    print(f"Saved {out}")

def plot_voltage_map_position(folder, direction, mode):
    pattern = f"line_scan_y*_ {direction}_{mode}_*.csv".replace("*_","*")
    files = _find_files(folder, pattern)
    if not files: return

    # base time→distance for first line
    df0 = pd.read_csv(files[0])
    t0 = df0.iloc[:,0].values - df0.iloc[0,0]
    D = abs(X_END - X_START)
    x_base = trapezoidal_profile(t0, D, ACC_X, VEL_X)*1000  # µm
    N = len(x_base)

    Vlines, Y = [], []
    for fn in files:
        idx = int(re.search(r"y(\d+)_", fn).group(1))
        Y.append((Y_START + idx*Y_STEP)*1000)
        v = pd.read_csv(fn).iloc[:,1].values
        if len(v)!=N:
            v = np.interp(np.linspace(0,1,N), np.linspace(0,1,len(v)), v)
        Vlines.append(v)
    Vmap = np.array(Vlines)
    Xgrid, Ygrid = np.meshgrid(x_base, Y)

    plt.figure(figsize=(8,6))
    plt.pcolormesh(Xgrid, Ygrid, Vmap, shading='auto')
    plt.colorbar(label="Voltage (V)")
    plt.xlabel("X Position (µm)"); plt.ylabel("Y Position (µm)")
    plt.title(f"DAQ Voltage Map vs Position ({direction}, {mode})")
    out = os.path.join(folder, f"spatial_map_position_{direction}_{mode}.png")
    plt.savefig(out, dpi=300); plt.close()
    print(f"Saved {out}")

def plot_vna_phase_first_line(folder, direction, mode):
    pattern = f"line_scan_y0_{direction}_{mode}_*.s2p"
    files = _find_files(folder, pattern)
    if not files: return
    phases = []
    with open(files[0],'r') as f:
        for line in f:
            if line.startswith("!") or line.startswith("#"): continue
            parts = line.split()
            phases.append(float(parts[4]))  # S21 phase
    # map to X positions
    pts = len(phases)
    D = abs(X_END - X_START)
    t_array = np.linspace(0, (D/VEL_X if SCAN_AXIS=='X' else D/VEL_Y), pts)
    x_pos = trapezoidal_profile(t_array, D, ACC_X, VEL_X)*1000
    plt.figure()
    plt.plot(x_pos, phases)
    plt.xlabel("X Position (µm)"); plt.ylabel("Phase (°)")
    plt.title(f"VNA Phase vs X (y=0, {direction}, {mode})")
    out = os.path.join(folder, f"vna_phase_y0_{direction}_{mode}.png")
    plt.savefig(out, dpi=300); plt.close()
    print(f"Saved {out}")

def plot_vna_real_first_line(folder, direction, mode):
    pattern = f"line_scan_y0_{direction}_{mode}_*.s2p"
    files = _find_files(folder, pattern)
    if not files: return
    real_vals = []
    with open(files[0],'r') as f:
        for line in f:
            if line.startswith("!") or line.startswith("#"): continue
            p = line.split()
            mag, ph = float(p[3]), float(p[4])
            real_vals.append(mag*np.cos(np.deg2rad(ph)))
    pts = len(real_vals)
    D = abs(X_END - X_START)
    t_array = np.linspace(0, (D/VEL_X if SCAN_AXIS=='X' else D/VEL_Y), pts)
    x_pos = trapezoidal_profile(t_array, D, ACC_X, VEL_X)*1000
    plt.figure()
    plt.plot(x_pos, real_vals)
    plt.xlabel("X Position (µm)"); plt.ylabel("Real(S21)")
    plt.title(f"VNA Real vs X (y=0, {direction}, {mode})")
    out = os.path.join(folder, f"vna_real_y0_{direction}_{mode}.png")
    plt.savefig(out, dpi=300); plt.close()
    print(f"Saved {out}")

def plot_vna_IQ_first_line(folder, direction, mode):
    pattern = f"line_scan_y0_{direction}_{mode}_*.s2p"
    files = _find_files(folder, pattern)
    if not files: return
    I,Q = [],[]
    with open(files[0],'r') as f:
        for line in f:
            if line.startswith("!") or line.startswith("#"): continue
            p = line.split()
            mag, ph = float(p[3]), float(p[4])
            I.append(mag*np.cos(np.deg2rad(ph)))
            Q.append(mag*np.sin(np.deg2rad(ph)))
    pts = len(I)
    D = abs(X_END - X_START)
    t_array = np.linspace(0, (D/VEL_X if SCAN_AXIS=='X' else D/VEL_Y), pts)
    x_pos = trapezoidal_profile(t_array, D, ACC_X, VEL_X)*1000
    plt.figure()
    plt.plot(x_pos, I, label="I"); plt.plot(x_pos, Q, label="Q")
    plt.xlabel("X Position (µm)"); plt.ylabel("I/Q")
    plt.title(f"VNA I & Q vs X (y=0, {direction}, {mode})")
    plt.legend()
    out = os.path.join(folder, f"vna_IQ_y0_{direction}_{mode}.png")
    plt.savefig(out, dpi=300); plt.close()
    print(f"Saved {out}")

# -----------------------------------------------------------------------------
# --------------------------------- MAIN --------------------------------------
# -----------------------------------------------------------------------------
def main():
    # connect to XPS
    global xps
    xps = XPS()
    check(to_rc(xps.OpenInstrument(XPS_IP, XPS_PORT, XPS_TIMEOUT)), "OpenInstrument")
    check(to_rc(xps.SetTimeout(XPS_TIMEOUT, XPS_TIMEOUT)),   "SetTimeout")
    print(f"Connected to XPS at {XPS_IP}:{XPS_PORT}")

    # home & profile
    home_axis(GROUP_X, VEL_X, ACC_X)
    home_axis(GROUP_Y, VEL_Y, ACC_Y)
    set_profile(GROUP_X, VEL_X, ACC_X)
    set_profile(GROUP_Y, VEL_Y, ACC_Y)

    # init VNA
    try:
        vna = initialize_vna()
        vna_params = {
            'frequency': 1024e6,
            'rf_power': 5,
            'if_bandwidth': 10,
            'points': 500
        }
        configure_vna(vna, **vna_params)
    except Exception as e:
        print("VNA init failed:", e)
        vna = None
        vna_params = {}

    # DAQ rate
    sampling_rate = 50.0  # Hz

    # output folder
    folder = "scan_" + datetime.now().strftime("%Y%m%d_%H%M%S")
    print("Saving data to:", folder)

    # calibration then measurement
    for mode in ("calibration","measurement"):
        run_raster_scan(folder, mode, sampling_rate, vna, {**vna_params, 'rf_power':vna_params.get('rf_power',5)})

    # cleanup
    try: xps.CloseInstrument()
    except: pass
    if vna: vna.close()

    # plots
    for mode in ("calibration","measurement"):
        for direction in ("forward","backward"):
            plot_daq_voltage_first_line(folder, direction, mode)
            plot_voltage_map_time(folder, direction, mode)
            plot_voltage_map_position(folder, direction, mode)
            plot_vna_phase_first_line(folder, direction, mode)
            plot_vna_real_first_line(folder, direction, mode)
            plot_vna_IQ_first_line(folder, direction, mode)

if __name__=="__main__":
    main()
