import sys, os, csv, time, re, glob
from datetime import datetime
import traceback
import tkinter as tk
from tkinter import ttk, messagebox

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from scipy.interpolate import interp1d

import nidaqmx
from nidaqmx.constants import AcquisitionType

import clr
from System.Text import StringBuilder

import pyvisa

# -----------------------------------------------------------------------------
# ------------------------- SCRIPT PARAMETERS ---------------------------------
# -----------------------------------------------------------------------------

# -- XPS Controller Connection --
XPS_IP = "192.168.0.254"
XPS_PORT = 5001
XPS_TIMEOUT = 600000  # ms

# -- Motion Groups & Names --
GROUP_X = "Group1"
GROUP_Y = "Group2"
POS_X = f"{GROUP_X}.Pos"
POS_Y = f"{GROUP_Y}.Pos"
TRIGGER_OUT_PORT = "Group1.DigitalOutput" # Digital output for DAQ/VNA trigger

# -- Scan & Motion Parameters (all values in micrometers or µm/s) --
UM_PER_MM = 1000.0

# Choose 'X' for continuous scans along X-axis, or 'Y' for scans along Y-axis
SCAN_AXIS = 'X'

# Scan dimensions relative to the start point set in the GUI
SCAN_WIDTH_UM = 10000.0   # 10 mm
SCAN_HEIGHT_UM = 5000.0   # 5 mm

# Spacing between continuous scan lines
LINE_SPACING_UM = 500.0  # 0.5 mm step

# Velocity (µm/s) and acceleration (µm/s²)
VEL_X_UM, ACC_X_UM = 2000.0, 5000.0  # 2 mm/s, 5 mm/s^2
VEL_Y_UM, ACC_Y_UM = 2000.0, 5000.0  # 2 mm/s, 5 mm/s^2

# -- NI DAQ Parameters --
DAQ_DEVICE_CHANNEL = "Dev1Mod1/ai3"
DAQ_TRIGGER_SOURCE = "PFI0"
DAQ_SAMPLING_RATE_HZ = 50.0

# -- VNA Parameters --
VNA_ADDRESS = 'TCPIP0::Eichenfield_LDV::hislip_PXI0_CHASSIS1_SLOT1_INDEX0::INSTR'
VNA_PARAMS = {
    'frequency': 1024e6,
    'rf_power': 5,
    'if_bandwidth': 10,
    'points': 500
}

# -----------------------------------------------------------------------------
# -------------------- MOTION PROFILE (TRAPEZOIDAL) ---------------------------
# -----------------------------------------------------------------------------
def trapezoidal_profile(t, D, a, v):
    """Calculates position over time for a trapezoidal/triangular velocity profile."""
    t = np.array(t)
    x = np.zeros_like(t)
    
    # Time to accelerate to max velocity v and distance covered
    t_a_max = v / a
    d_a_max = 0.5 * a * t_a_max**2

    # Check for trapezoidal vs. triangular profile
    if D >= 2 * d_a_max:
        # ---- Trapezoidal Case ----
        t_a = t_a_max
        T = (D / v) + (v / a) # Total move time
        
        mask_a = t < t_a
        x[mask_a] = 0.5 * a * t[mask_a]**2
        
        mask_c = (t >= t_a) & (t <= T - t_a)
        x[mask_c] = d_a_max + v * (t[mask_c] - t_a)
        
        mask_d = t > (T - t_a)
        t_dec = t[mask_d] - (T - t_a)
        x[mask_d] = D - 0.5 * a * (t_a - t_dec)**2
        
    else:
        # ---- Triangular Case ----
        t_a = np.sqrt(D / a) # Time to reach peak velocity
        T = 2 * t_a          # Total move time
        
        mask_a = t <= t_a
        x[mask_a] = 0.5 * a * t[mask_a]**2
        
        mask_d = t > t_a
        x[mask_d] = D - 0.5 * a * (T - t[mask_d])**2

    return np.minimum(x, D)

# -----------------------------------------------------------------------------
# ------------------------- XPS CONTROLLER CLASS ------------------------------
# -----------------------------------------------------------------------------
try:
    clr.AddReference(
        r"C:\Windows\Microsoft.NET\assembly\GAC_64\Newport.XPS.CommandInterface"
        r"\v4.0_2.3.1.0__9a267756cf640dcf\Newport.XPS.CommandInterface.dll"
    )
    from CommandInterfaceXPS import XPS
except Exception as e:
    print("FATAL ERROR: Could not load Newport XPS .NET assembly.")
    print(f"Details: {e}")
    sys.exit(1)

class XPSController:
    """A wrapper class for the XPS hardware controller. All methods expect units in mm."""
    def __init__(self, ip, port, timeout):
        self.xps = XPS()
        self.is_connected = False
        rc = self._to_rc(self.xps.OpenInstrument(ip, port, timeout))
        self._check(rc, "OpenInstrument")
        print(f"Connected to XPS at {ip}:{port}")
        self.is_connected = True

    def _to_rc(self, ret):
        return ret if isinstance(ret, int) else ret[0]

    def _check(self, rc, name):
        if rc != 0:
            error_string_tuple = self.xps.ErrorStringGet(rc)
            raise RuntimeError(f"{name} failed (code={rc}): {error_string_tuple[1]}")

    def home_axis(self, group, pos, vel_mm, acc_mm):
        print(f"Homing {group}…")
        self._check(self._to_rc(self.xps.GroupInitialize(group)), f"GroupInitialize {group}")
        self._check(self._to_rc(self.xps.PositionerSGammaParametersSet(pos, vel_mm, acc_mm, 0.001, 0.005)), f"SGammaSet {pos}")
        self._check(self._to_rc(self.xps.GroupHomeSearch(group)), f"GroupHomeSearch {group}")
        self.wait_for_status(group, 11, timeout=60)
        print(f"{group} homed.")

    def set_motion_profile(self, group, pos, vel_mm, acc_mm):
        self._check(self._to_rc(self.xps.PositionerSGammaParametersSet(pos, vel_mm, acc_mm, 0.001, 0.005)), f"SGammaSet {pos}")
        print(f"Motion profile set for {group} (V={vel_mm} mm/s, A={acc_mm} mm/s^2).")

    def move_absolute(self, group, target_mm):
        self._check(self._to_rc(self.xps.GroupMoveAbsolute(group, [target_mm], 1)), f"MoveAbsolute {group} to {target_mm:.4f} mm")
        self.wait_for_status(group, 12)

    def move_relative(self, group, distance_mm):
        self._check(self._to_rc(self.xps.GroupMoveRelative(group, [distance_mm], 1)), f"MoveRelative {group}")
        self.wait_for_status(group, 12)

    def wait_for_status(self, group, desired_status, timeout=30.0):
        t0 = time.time()
        while True:
            ret = self.xps.GroupStatusGet(group)
            rc, status = self._to_rc(ret), ret[1]
            self._check(rc, f"GroupStatusGet {group}")
            if status == desired_status:
                return
            if time.time() - t0 > timeout:
                raise TimeoutError(f"{group} did not reach status {desired_status} in time.")
            time.sleep(0.05)

    def setup_motion_trigger(self):
        """Configures the XPS to output a trigger pulse at the start of a move."""
        action_name = "TriggerPulse"
        event_name = "StartOfTrajectory"
        self._check(self._to_rc(self.xps.EventExtendedConfigurationActionSet(
            action_name, TRIGGER_OUT_PORT, "Set", "1"
        )), "EventExtendedConfigurationActionSet (Set High)")
        self._check(self._to_rc(self.xps.EventExtendedConfigurationTriggerSet(
            event_name, action_name
        )), "EventExtendedConfigurationTriggerSet")
        print(f"XPS trigger configured on {TRIGGER_OUT_PORT} for event '{event_name}'")

    def close(self):
        if self.is_connected:
            self.xps.CloseInstrument()
            print("Disconnected from XPS.")
            self.is_connected = False
            
# -----------------------------------------------------------------------------
# -------------------------- POSITIONING GUI CLASS ----------------------------
# -----------------------------------------------------------------------------

class PositioningGUI:
    """A Tkinter GUI that tracks position internally in micrometers."""
    def __init__(self, controller):
        self.controller = controller
        self.scan_started = False
        self.tracked_x_um = 0.0
        self.tracked_y_um = 0.0
        self.start_x_um = 0.0
        self.start_y_um = 0.0

        self.root = tk.Tk()
        self.root.title("XPS Stage Positioning (µm)")
        self.root.protocol("WM_DELETE_WINDOW", self._on_closing)

        frame = ttk.Frame(self.root, padding="10")
        frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        self.x_pos_var = tk.StringVar(value=f"X: {self.tracked_x_um:9.1f} µm")
        self.y_pos_var = tk.StringVar(value=f"Y: {self.tracked_y_um:9.1f} µm")
        ttk.Label(frame, textvariable=self.x_pos_var, font=("Courier", 12)).grid(row=0, column=0, columnspan=3, sticky=tk.W)
        ttk.Label(frame, textvariable=self.y_pos_var, font=("Courier", 12)).grid(row=1, column=0, columnspan=3, sticky=tk.W)

        ttk.Label(frame, text="Step Size (µm):").grid(row=2, column=0, sticky=tk.W, pady=10)
        self.step_var = tk.StringVar(value="1000.0")
        ttk.Entry(frame, textvariable=self.step_var, width=10).grid(row=2, column=1, columnspan=2, sticky=tk.W)

        ttk.Button(frame, text="Y+", command=lambda: self._jog(GROUP_Y, 1)).grid(row=3, column=1)
        ttk.Button(frame, text="X-", command=lambda: self._jog(GROUP_X, -1)).grid(row=4, column=0)
        ttk.Button(frame, text="X+", command=lambda: self._jog(GROUP_X, 1)).grid(row=4, column=2)
        ttk.Button(frame, text="Y-", command=lambda: self._jog(GROUP_Y, -1)).grid(row=5, column=1, pady=5)
        
        ttk.Separator(frame, orient='horizontal').grid(row=6, column=0, columnspan=3, sticky='ew', pady=10)
        ttk.Button(frame, text="Start Scan at Current Position", command=self._start_scan, style="Accent.TButton").grid(row=7, column=0, columnspan=3, sticky='ew', ipady=5)
        
        style = ttk.Style()
        style.configure("Accent.TButton", foreground="white", background="green", font=('calibri', 10, 'bold'))

    def _jog(self, group, direction):
        try:
            # Get the step size from the GUI entry box
            step_um = float(self.step_var.get())
            
            # Calculate the distance to move IN MILLIMETERS for the controller
            distance_mm = (step_um / UM_PER_MM) * direction
            
            # Command the controller to move by the signed distance
            self.controller.move_relative(group, distance_mm)

            # Update the internal position tracker for the GUI display
            if group == GROUP_X:
                self.tracked_x_um += direction * step_um
                self.x_pos_var.set(f"X: {self.tracked_x_um:9.1f} µm")
            else:
                self.tracked_y_um += direction * step_um
                self.y_pos_var.set(f"Y: {self.tracked_y_um:9.1f} µm")

        except ValueError:
            messagebox.showerror("Invalid Input", "Step size must be a number.")
        except Exception as e:
            messagebox.showerror("Motion Error", str(e))

    def _start_scan(self):
        self.start_x_um = self.tracked_x_um
        self.start_y_um = self.tracked_y_um
        print(f"Scan start position set from tracked location ({self.start_x_um:.1f}, {self.start_y_um:.1f}) µm.")
        self.scan_started = True
        self.root.destroy()
        print("GUI closed. Starting scan...")

    def _on_closing(self):
        if messagebox.askokcancel("Quit", "Do you want to exit without scanning?"):
            self.scan_started = False
            self.root.destroy()

    def run(self):
        self.root.mainloop()

# -----------------------------------------------------------------------------
# ------------------------- VNA & DAQ HELPERS ---------------------------------
# -----------------------------------------------------------------------------
def initialize_vna():
    rm = pyvisa.ResourceManager()
    vna = rm.open_resource(VNA_ADDRESS)
    vna.timeout = 1_000_000
    print("VNA ID:", vna.query("*IDN?"))
    return vna

def configure_vna(vna, **params):
    vna.write("SENS:SWE:TYPE CW")
    vna.write(f"SENS:FREQ:CW {params['frequency']}")
    vna.write(f"SOUR:POW {params['rf_power']}")
    vna.write(f"SENS:BAND {params['if_bandwidth']}")
    vna.write(f"SENS:SWE:POIN {params['points']}")
    vna.write("CALC:PAR:DEF 'Meas1', S11")
    vna.write("CALC:PAR:DEF 'Meas2', S21")
    vna.write("DISP:WIND:TRAC:Y:AUTO")

def parse_sdata(sdata):
    nums = list(map(float, sdata.split(',')))
    cmplx = [complex(nums[i], nums[i+1]) for i in range(0, len(nums), 2)]
    return [(abs(c), np.angle(c, deg=True)) for c in cmplx]

def save_s2p(s11_data, s21_data, filename, frequency, **kwargs):
    s11 = parse_sdata(s11_data)
    s21 = parse_sdata(s21_data)
    with open(filename, 'w') as f:
        f.write("! S2P Data\n# Hz S MA R 50\n")
        for (m11, p11), (m21, p21) in zip(s11, s21):
            f.write(f"{frequency} {m11} {p11} {m21} {p21} 1e-10 45 1e-10 45\n")

# -----------------------------------------------------------------------------
# ------------------------- SCAN & DATA COLLECTION ----------------------------
# -----------------------------------------------------------------------------
def perform_raster_scan(controller, folder, mode, start_x_um, start_y_um, vna, vna_params):
    os.makedirs(folder, exist_ok=True)

    if mode == 'calibration' and vna:
        vna.write("OUTP OFF")

    # Define scan axes based on global SCAN_AXIS parameter
    if SCAN_AXIS == 'X':
        fast_group, slow_group = GROUP_X, GROUP_Y
        scan_dist_um, num_lines = SCAN_WIDTH_UM, int(SCAN_HEIGHT_UM / LINE_SPACING_UM) + 1
        slow_positions_um = [start_y_um + i * LINE_SPACING_UM for i in range(num_lines)]
        fast_start_um, fast_end_um = start_x_um, start_x_um + scan_dist_um
        fast_vel, fast_acc = VEL_X_UM, ACC_X_UM
    else: # SCAN_AXIS == 'Y'
        fast_group, slow_group = GROUP_Y, GROUP_X
        scan_dist_um, num_lines = SCAN_HEIGHT_UM, int(SCAN_WIDTH_UM / LINE_SPACING_UM) + 1
        slow_positions_um = [start_x_um + i * LINE_SPACING_UM for i in range(num_lines)]
        fast_start_um, fast_end_um = start_y_um, start_y_um + scan_dist_um
        fast_vel, fast_acc = VEL_Y_UM, ACC_Y_UM

    if mode == 'calibration':
        num_lines = 1

    for i in range(num_lines):
        slow_pos_um = slow_positions_um[i]
        
        # Move to the position for the current line
        controller.move_absolute(slow_group, slow_pos_um / UM_PER_MM)
        
        # Determine scan direction for serpentine motion
        direction = 'forward' if (i % 2) == 0 else 'backward'
        scan_start_um = fast_start_um if direction == 'forward' else fast_end_um
        scan_end_um = fast_end_um if direction == 'forward' else fast_start_um
        
        # Move to the start of the line before starting acquisition
        controller.move_absolute(fast_group, scan_start_um / UM_PER_MM)
        
        ts = int(time.time() * 1000)
        file_prefix = f"line_{i}_{direction}_{mode}_{ts}"
        csv_path = os.path.join(folder, file_prefix + ".csv")
        s2p_path = os.path.join(folder, file_prefix + ".s2p")
        
        print(f"  Scanning line {i+1}/{num_lines} ({direction}) for {mode}...")

        with nidaqmx.Task() as task:
            task.ai_channels.add_ai_voltage_chan(DAQ_DEVICE_CHANNEL)
            task.timing.cfg_samp_clk_timing(
                DAQ_SAMPLING_RATE_HZ, sample_mode=AcquisitionType.CONTINUOUS
            )
            # Configure DAQ to wait for a digital trigger
            task.triggers.start_trigger.cfg_dig_edge_start_trig(DAQ_TRIGGER_SOURCE)

            # Arm the DAQ: It's now waiting for the trigger
            task.start()

            if vna:
                vna.write("INIT:CONT OFF")
                line_time_s = (scan_dist_um / fast_vel) + (fast_vel / fast_acc)
                vna.write(f"SENS:SWE:TIME {line_time_s * 1.1}") # Add 10% buffer
                vna.write("TRIG:SOUR EXT") # Set VNA to wait for external trigger
                vna.write("INIT") # Arm the VNA

            # Move fast axis: This action sends the trigger pulse from the XPS,
            # which starts the DAQ and VNA simultaneously.
            # The function blocks until motion is done.
            controller.move_absolute(fast_group, scan_end_um / UM_PER_MM)

            # Motion is complete, now read all data from the DAQ buffer
            task.timeout = 10.0 # seconds
            data = task.read(number_of_samples_per_channel=nidaqmx.constants.READ_ALL_AVAILABLE)
            task.stop()

            if data:
                num_samples = len(data)
                time_vector = np.arange(num_samples) / DAQ_SAMPLING_RATE_HZ
                with open(csv_path, 'w', newline='') as f:
                    w = csv.writer(f)
                    w.writerow(["Time (s)", "Voltage (V)"])
                    w.writerows(zip(time_vector, data))

            if vna:
                vna.query("*OPC?")
                vna.write("CALC:PAR:SEL 'Meas1'")
                s11 = vna.query("CALC:DATA? SDATA").strip()
                vna.write("CALC:PAR:SEL 'Meas2'")
                s21 = vna.query("CALC:DATA? SDATA").strip()
                save_s2p(s11, s21, s2p_path, **vna_params)

            print(f"    Line data saved → {os.path.basename(csv_path)}")

    if mode == 'calibration' and vna:
        vna.write("OUTP ON")
        vna.write(f"SOUR:POW {vna_params['rf_power']}")

# -----------------------------------------------------------------------------
# ---------------------------- PLOTTING FUNCTIONS -----------------------------
# -----------------------------------------------------------------------------
def _find_files(folder, pattern):
    return sorted(glob.glob(os.path.join(folder, pattern)))

def plot_daq_voltage_first_line(folder, direction, mode, scan_width_mm, acc_mm_s2, vel_mm_s):
    pattern = f"line_0_{direction}_{mode}_*.csv"
    files = _find_files(folder, pattern)
    if not files: return
    
    df = pd.read_csv(files[0])
    t, v = df.iloc[:,0].values, df.iloc[:,1].values
    if len(t) == 0: return

    # Time plot
    plt.figure()
    plt.plot(t, v)
    plt.xlabel("Time (s)"); plt.ylabel("Voltage (V)")
    plt.title(f"DAQ Voltage vs Time (Line 0, {direction}, {mode})")
    plt.savefig(os.path.join(folder, f"daq_time_line0_{direction}_{mode}.png"), dpi=300); plt.close()

    # Position plot
    x_pos = trapezoidal_profile(t, scan_width_mm, acc_mm_s2, vel_mm_s) * UM_PER_MM # to µm
    plt.figure()
    plt.plot(x_pos, v)
    plt.xlabel("Position (µm)"); plt.ylabel("Voltage (V)")
    plt.title(f"DAQ Voltage vs Position (Line 0, {direction}, {mode})")
    plt.savefig(os.path.join(folder, f"daq_position_line0_{direction}_{mode}.png"), dpi=300); plt.close()
    print(f"Plotted first-line DAQ for {direction}/{mode}")

def plot_voltage_map_position(folder, mode, start_pos_um, scan_width_mm, line_spacing_um, acc_mm_s2, vel_mm_s):
    pattern = f"line_*_*_{mode}_*.csv"
    files = _find_files(folder, pattern)
    if len(files) < 2: return # Need at least 2 lines for a map

    all_y_coords, resampled_volts = [], []
    num_interp_points = 1000
    x_uniform_um = np.linspace(start_pos_um[0], start_pos_um[0] + (scan_width_mm * UM_PER_MM), num_interp_points)

    for fn in files:
        match = re.search(r"line_(\d+)_(forward|backward)_", fn)
        if not match: continue
        
        idx, direction = int(match.group(1)), match.group(2)
        y_pos_um = start_pos_um[1] + idx * line_spacing_um
        all_y_coords.append(y_pos_um)

        df = pd.read_csv(fn)
        time_s, voltage_v = df.iloc[:, 0].values, df.iloc[:, 1].values
        
        if len(time_s) == 0:
            resampled_volts.append(np.full(num_interp_points, np.nan))
            continue

        actual_positions_mm = trapezoidal_profile(time_s, scan_width_mm, acc_mm_s2, vel_mm_s)
        actual_positions_um = start_pos_um[0] + (actual_positions_mm * UM_PER_MM)
        
        if direction == 'backward':
            actual_positions_um = (start_pos_um[0] + scan_width_mm * UM_PER_MM) - (actual_positions_mm * UM_PER_MM)
        
        f_interp = interp1d(actual_positions_um, voltage_v, bounds_error=False, fill_value=np.nan)
        v_resampled = f_interp(x_uniform_um)
        resampled_volts.append(v_resampled)
    
    # Sort data by Y-coordinate before plotting
    sorted_indices = np.argsort(all_y_coords)
    Ygrid_vec = np.array(all_y_coords)[sorted_indices]
    Vmap = np.array(resampled_volts)[sorted_indices]
    
    Xgrid, Ygrid = np.meshgrid(x_uniform_um, Ygrid_vec)

    plt.figure(figsize=(8, 6))
    plt.pcolormesh(Xgrid, Ygrid, Vmap, shading='auto', cmap='viridis')
    plt.colorbar(label="Voltage (V)")
    plt.xlabel("X Position (µm)"); plt.ylabel("Y Position (µm)")
    plt.title(f"DAQ Voltage Map vs Position ({mode})")
    out = os.path.join(folder, f"spatial_map_position_{mode}.png")
    plt.savefig(out, dpi=300); plt.close()
    print(f"Plotted spatial map for {mode}")

# -----------------------------------------------------------------------------
# --------------------------------- MAIN --------------------------------------
# -----------------------------------------------------------------------------
def main():
    controller = None
    vna = None
    try:
        # ---- Initialize Instruments ----
        controller = XPSController(XPS_IP, XPS_PORT, XPS_TIMEOUT)
        
        # Convert µm parameters to mm for hardware setup
        vel_x_mm, acc_x_mm = VEL_X_UM / UM_PER_MM, ACC_X_UM / UM_PER_MM
        vel_y_mm, acc_y_mm = VEL_Y_UM / UM_PER_MM, ACC_Y_UM / UM_PER_MM

        controller.home_axis(GROUP_X, POS_X, vel_x_mm, acc_x_mm)
        controller.home_axis(GROUP_Y, POS_Y, vel_y_mm, acc_y_mm)
        controller.set_motion_profile(GROUP_X, POS_X, vel_x_mm, acc_x_mm)
        controller.set_motion_profile(GROUP_Y, POS_Y, vel_y_mm, acc_y_mm)
        
        controller.setup_motion_trigger()

        # ---- Launch GUI for Positioning ----
        gui = PositioningGUI(controller)
        gui.run()

        if not gui.scan_started:
            print("GUI was closed without starting the scan. Exiting.")
            return

        start_x_um, start_y_um = gui.start_x_um, gui.start_y_um

        try:
            vna = initialize_vna()
            configure_vna(vna, **VNA_PARAMS)
        except Exception as e:
            print(f"VNA initialization failed: {e}. Continuing without VNA.")
            vna = None

        # ---- Run Scans ----
        folder = "scan_" + datetime.now().strftime("%Y%m%d_%H%M%S")
        print(f"Saving data to: {folder}")
        
        for mode in ("calibration", "measurement"):
            print("-" * 30)
            print(f"Starting {mode.title()} Scan...")
            perform_raster_scan(controller, folder, mode, start_x_um, start_y_um, vna, VNA_PARAMS)
        
        print("\nScan complete.")
        print(f"Returning to start position ({start_x_um:.1f}, {start_y_um:.1f}) µm.")
        controller.move_absolute(GROUP_X, start_x_um / UM_PER_MM)
        controller.move_absolute(GROUP_Y, start_y_um / UM_PER_MM)

    except (RuntimeError, TimeoutError, ConnectionError) as e:
        print(f"\nAN ERROR OCCURRED: {e}")
        traceback.print_exc()
    finally:
        if controller:
            controller.close()
        if vna:
            vna.close()

    # ---- Generate Plots ----
    print("\n" + "-" * 30)
    print("--- Generating Plots ---")
    
    # Plotting parameters (assuming X is the fast scan axis)
    plot_scan_width_mm = SCAN_WIDTH_UM / UM_PER_MM
    plot_acc_mm_s2 = ACC_X_UM / UM_PER_MM
    plot_vel_mm_s = VEL_X_UM / UM_PER_MM

    for mode in ("calibration", "measurement"):
        plot_daq_voltage_first_line(folder, 'forward', mode, plot_scan_width_mm, plot_acc_mm_s2, plot_vel_mm_s)
        if mode == "measurement":
            plot_voltage_map_position(folder, mode, (start_x_um, start_y_um), plot_scan_width_mm, LINE_SPACING_UM, plot_acc_mm_s2, plot_vel_mm_s)

    print("--- Plotting Complete ---")
    input("Press Enter to exit...")


if __name__ == "__main__":
    main()