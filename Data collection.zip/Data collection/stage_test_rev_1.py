import clr
import time
import traceback
import tkinter as tk
from tkinter import ttk, messagebox

# ---------------------------------------------------------------------------
# Python script to connect to Newport XPS-D, home axes, and allow a user
# to position the stage via a GUI. The script tracks the position internally
# without reading it back from the controller.
#
# Revision 5: Removed get_position() and replaced it with internal tracking.
# ---------------------------------------------------------------------------

# 1) Load the XPS .NET assembly
try:
    clr.AddReference(
        r"C:\Windows\Microsoft.NET\assembly\GAC_64\Newport.XPS.CommandInterface"
        r"\v4.0_2.3.1.0__9a267756cf640dcf\Newport.XPS.CommandInterface.dll"
    )
    from CommandInterfaceXPS import XPS
except Exception as e:
    print("FATAL ERROR: Could not load Newport XPS .NET assembly.")
    print("Please check the DLL path in the script.")
    print(f"Details: {e}")
    input("Press Enter to exit...")
    exit()

# -------------------------
# CONNECTION & TIMEOUT
# -------------------------
IP = "192.168.0.254"
PORT = 5001
TIMEOUT_MS = 60000

# -------------------------
# SCAN & MOTION PARAMETERS
# -------------------------
GROUP_X = "Group1"
GROUP_Y = "Group2"
POS_X = f"{GROUP_X}.Pos"
POS_Y = f"{GROUP_Y}.Pos"

# Scan dimensions and step in mm (relative to the start point set in the GUI)
SCAN_WIDTH = 10.0
SCAN_HEIGHT = 10.0
X_STEP = 1.0
Y_STEP = 1.0

# Velocity (mm/s) and acceleration (mm/s²)
VEL_X, ACC_X = 10.0, 20.0
VEL_Y, ACC_Y = 10.0, 20.0

# Choose 'X' to scan lines along X (vary X for each Y), or 'Y' to scan along Y
SCAN_AXIS = 'X'

# ===========================================================================
# XPS Controller Class (encapsulates all hardware communication)
# ===========================================================================

class XPSController:
    """A wrapper class for the XPS hardware controller."""
    def __init__(self, ip, port, timeout):
        self.xps = XPS()
        self.is_connected = False
        rc = self._to_rc(self.xps.OpenInstrument(ip, port, timeout))
        self._check(rc, "OpenInstrument")
        print(f"Connected to XPS at {ip}:{port}")
        self.is_connected = True

    def _to_rc(self, ret):
        return ret if isinstance(ret, int) else ret[0]

    def _check(self, rc, name):
        if rc != 0:
            error_string_tuple = self.xps.ErrorStringGet(rc)
            raise RuntimeError(f"{name} failed (code={rc}): {error_string_tuple[1]}")

    def home_axis(self, group, pos, vel, acc):
        print(f"Homing {group}…")
        self._check(self._to_rc(self.xps.GroupInitialize(group)), f"GroupInitialize {group}")
        self._check(self._to_rc(self.xps.PositionerSGammaParametersSet(pos, vel, acc, 0.001, 0.005)), f"SGammaSet {pos}")
        self._check(self._to_rc(self.xps.GroupHomeSearch(group)), f"GroupHomeSearch {group}")
        self.wait_for_status(group, 11, timeout=60)
        print(f"{group} homed.")

    def set_motion_profile(self, group, pos, vel, acc):
        self._check(self._to_rc(self.xps.PositionerSGammaParametersSet(pos, vel, acc, 0.001, 0.005)), f"SGammaSet {pos}")
        print(f"Motion profile set for {group}.")

    def move_absolute(self, group, target):
        self._check(self._to_rc(self.xps.GroupMoveAbsolute(group, [target], 1)), f"MoveAbsolute {group} to {target:.3f}")
        self.wait_for_status(group, 12)

    def move_relative(self, group, distance):
        self._check(self._to_rc(self.xps.GroupMoveRelative(group, [distance], 1)), f"MoveRelative {group}")
        self.wait_for_status(group, 12)

    def wait_for_status(self, group, desired_status, timeout=30.0):
        t0 = time.time()
        while True:
            ret = self.xps.GroupStatusGet(group)
            rc, status = self._to_rc(ret), ret[1]
            self._check(rc, f"GroupStatusGet {group}")
            if status == desired_status:
                return
            if time.time() - t0 > timeout:
                raise TimeoutError(f"{group} did not reach status {desired_status} in time.")
            time.sleep(0.05)

    def close(self):
        if self.is_connected:
            self.xps.CloseInstrument()
            print("Disconnected from XPS.")
            self.is_connected = False

# ===========================================================================
# Positioning GUI Class
# ===========================================================================

class PositioningGUI:
    """A Tkinter GUI that tracks position internally."""
    def __init__(self, controller):
        self.controller = controller
        self.scan_started = False

        # Internal variables to track the stage's position
        self.tracked_x = 0.0
        self.tracked_y = 0.0

        # These will hold the final start position for the scan
        self.start_x = 0.0
        self.start_y = 0.0

        # --- Window Setup ---
        self.root = tk.Tk()
        self.root.title("XPS Stage Positioning")
        self.root.protocol("WM_DELETE_WINDOW", self._on_closing)

        # --- Widgets ---
        frame = ttk.Frame(self.root, padding="10")
        frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        self.x_pos_var = tk.StringVar(value=f"X: {self.tracked_x:8.3f} mm")
        self.y_pos_var = tk.StringVar(value=f"Y: {self.tracked_y:8.3f} mm")
        ttk.Label(frame, textvariable=self.x_pos_var, font=("Courier", 12)).grid(row=0, column=0, columnspan=3, sticky=tk.W)
        ttk.Label(frame, textvariable=self.y_pos_var, font=("Courier", 12)).grid(row=1, column=0, columnspan=3, sticky=tk.W)

        ttk.Label(frame, text="Step Size (mm):").grid(row=2, column=0, sticky=tk.W, pady=10)
        self.step_var = tk.StringVar(value="1.0")
        ttk.Entry(frame, textvariable=self.step_var, width=10).grid(row=2, column=1, columnspan=2, sticky=tk.W)

        ttk.Button(frame, text="Y+", command=lambda: self._jog(GROUP_Y, 1)).grid(row=3, column=1)
        ttk.Button(frame, text="X-", command=lambda: self._jog(GROUP_X, -1)).grid(row=4, column=0)
        ttk.Button(frame, text="X+", command=lambda: self._jog(GROUP_X, 1)).grid(row=4, column=2)
        ttk.Button(frame, text="Y-", command=lambda: self._jog(GROUP_Y, -1)).grid(row=5, column=1, pady=5)
        
        ttk.Separator(frame, orient='horizontal').grid(row=6, column=0, columnspan=3, sticky='ew', pady=10)
        ttk.Button(frame, text="Start Scan at Current Position", command=self._start_scan, style="Accent.TButton").grid(row=7, column=0, columnspan=3, sticky='ew', ipady=5)
        
        style = ttk.Style()
        style.configure("Accent.TButton", foreground="white", background="green", font=('calibri', 10, 'bold'))

    def _jog(self, group, direction):
        try:
            step = float(self.step_var.get())
            # 1. Move the physical stage
            self.controller.move_relative(group, direction * step)

            # 2. Update the internal tracked position
            if group == GROUP_X:
                self.tracked_x += direction * step
                self.x_pos_var.set(f"X: {self.tracked_x:8.3f} mm")
            else: # group == GROUP_Y
                self.tracked_y += direction * step
                self.y_pos_var.set(f"Y: {self.tracked_y:8.3f} mm")

        except ValueError:
            messagebox.showerror("Invalid Input", "Step size must be a number.")
        except Exception as e:
            messagebox.showerror("Motion Error", str(e))

    def _start_scan(self):
        # Set the scan start position from our tracked variables
        self.start_x = self.tracked_x
        self.start_y = self.tracked_y
        
        print(f"Scan start position set from tracked location ({self.start_x:.3f}, {self.start_y:.3f}).")
        self.scan_started = True
        self.root.destroy()
        print("GUI closed. Starting scan...")

    def _on_closing(self):
        if messagebox.askokcancel("Quit", "Do you want to exit without scanning?"):
            self.scan_started = False
            self.root.destroy()

    def run(self):
        self.root.mainloop()

# ===========================================================================
# Main Execution Logic
# ===========================================================================

def main():
    controller = None
    try:
        controller = XPSController(IP, PORT, TIMEOUT_MS)
        controller.home_axis(GROUP_X, POS_X, VEL_X, ACC_X)
        controller.home_axis(GROUP_Y, POS_Y, VEL_Y, ACC_Y)
        controller.set_motion_profile(GROUP_X, POS_X, VEL_X, ACC_X)
        controller.set_motion_profile(GROUP_Y, POS_Y, VEL_Y, ACC_Y)
        
        gui = PositioningGUI(controller)
        gui.run()

        if not gui.scan_started:
            print("GUI was closed without starting the scan. Exiting.")
            return

        start_x, start_y = gui.start_x, gui.start_y
        xs = [start_x + i * X_STEP for i in range(int(SCAN_WIDTH / X_STEP) + 1)]
        ys = [start_y + j * Y_STEP for j in range(int(SCAN_HEIGHT / Y_STEP) + 1)]

        print("-" * 30)
        print(f"Starting {SCAN_AXIS}-axis scan from ({start_x:.3f}, {start_y:.3f})")
        
        # This first move syncs the controller to the tracked start position
        print("Moving to initial scan position...")
        controller.move_absolute(GROUP_X, start_x)
        controller.move_absolute(GROUP_Y, start_y)

        if SCAN_AXIS == 'X':
            for row, y in enumerate(ys):
                controller.move_absolute(GROUP_Y, y)
                seq = xs if (row % 2) == 0 else list(reversed(xs))
                for x in seq:
                    controller.move_absolute(GROUP_X, x)
                    print(f"  At X={x:.3f}, Y={y:.3f}")
        elif SCAN_AXIS == 'Y':
            for col, x in enumerate(xs):
                controller.move_absolute(GROUP_X, x)
                seq = ys if (col % 2) == 0 else list(reversed(ys))
                for y in seq:
                    controller.move_absolute(GROUP_Y, y)
                    print(f"  At X={x:.3f}, Y={y:.3f}")

        print("\nScan complete.")
        print("Returning to start position.")
        controller.move_absolute(GROUP_X, start_x)
        controller.move_absolute(GROUP_Y, start_y)

    except (RuntimeError, TimeoutError, ConnectionError) as e:
        print(f"\nAN ERROR OCCURRED: {e}")
        traceback.print_exc()
    finally:
        if controller:
            controller.close()
        input("Press Enter to exit...")

if __name__ == "__main__":
    main()