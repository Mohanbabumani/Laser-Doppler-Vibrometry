import clr
import time
import traceback
import nidaqmx
import numpy as np
import matplotlib.pyplot as plt
import tkinter as tk
from tkinter import ttk, messagebox
import threading

# ---------------------------------------------------------------------------
# Python script to find the optimal Z-axis position for a probe by
# maximizing a voltage signal from a DAQ.
#
# 1. Connects to Newport XPS-D controller and NI-DAQ.
# 2. Homes the Z-axis.
# 3. Provides a GUI for coarse manual positioning.
# 4. Runs an automated gradient ascent algorithm to find the peak voltage.
# 5. Includes an emergency stop and plots the results.
# ---------------------------------------------------------------------------

# 1) Load the XPS .NET assembly (Update this path if necessary)
try:
    clr.AddReference(
        r"C:\Windows\Microsoft.NET\assembly\GAC_64\Newport.XPS.CommandInterface"
        r"\v4.0_2.3.1.0__9a267756cf640dcf\Newport.XPS.CommandInterface.dll"
    )
    from CommandInterfaceXPS import XPS
except Exception as e:
    print("FATAL ERROR: Could not load Newport XPS .NET assembly.")
    print(f"Details: {e}")
    input("Press Enter to exit...")
    exit()

# Conversion constant
UM_PER_MM = 1000.0

# ===========================================================================
#  HARDWARE & ALGORITHM PARAMETERS
# ===========================================================================

# -------------------------
# XPS CONNECTION & TIMEOUT
# -------------------------
XPS_IP = "192.168.0.254"
XPS_PORT = 5001
XPS_TIMEOUT_MS = 600000

# -------------------------
# Z-AXIS MOTION PARAMETERS (ALL VALUES IN MICROMETERS)
# -------------------------
GROUP_Z = "Group3"
POS_Z = f"{GROUP_Z}.Pos"
VEL_Z_UM, ACC_Z_UM = 2000.0, 4000.0  # 2 mm/s, 4 mm/s^2

# -------------------------
# NI-DAQ PARAMETERS
# -------------------------
DAQ_CHANNEL = "Dev1Mod1/ai3"
DAQ_SAMPLES_PER_READ = 20
DAQ_SAMPLING_RATE_HZ = 1000.0

# -------------------------
# GRADIENT ASCENT PARAMETERS
# -------------------------
# The initial step size for the search in µm
INITIAL_STEP_UM = 5.0
# The smallest step size before the algorithm terminates in µm
MIN_STEP_UM = 0.1
# Factor by which to reduce the step size after passing a peak (e.g., 0.5 = halve the step)
STEP_REDUCTION_FACTOR = 0.4
# Initial search direction: -1 for down (closer to sample), 1 for up
INITIAL_SEARCH_DIRECTION = -1
# Safety limit: max distance in µm from start point before auto-stopping
MAX_SEARCH_RANGE_UM = 500.0

# Global flag for emergency stop
stop_flag = threading.Event()

# ===========================================================================
# XPS Controller Class
# ===========================================================================
class XPSController:
    """A wrapper class for the XPS hardware controller. All methods expect units in mm."""
    def __init__(self, ip, port, timeout):
        self.xps = XPS()
        self.is_connected = False
        rc = self._to_rc(self.xps.OpenInstrument(ip, port, timeout))
        self._check(rc, "OpenInstrument")
        print(f"Connected to XPS at {ip}:{port}")
        self.is_connected = True

    def _to_rc(self, ret):
        return ret if isinstance(ret, int) else ret[0]

    def _check(self, rc, name):
        if rc != 0:
            err_str = self.xps.ErrorStringGet(rc)[1]
            raise RuntimeError(f"XPS Error in {name} (code={rc}): {err_str}")

    def home_axis(self, group, pos, vel_mm, acc_mm):
        print(f"Homing {group}...")
        self._check(self._to_rc(self.xps.GroupInitialize(group)), f"GroupInitialize {group}")
        self._check(self._to_rc(self.xps.PositionerSGammaParametersSet(pos, vel_mm, acc_mm, 0.001, 0.005)), f"SGammaSet {pos}")
        self._check(self._to_rc(self.xps.GroupHomeSearch(group)), f"GroupHomeSearch {group}")
        self.wait_for_move_end(group, timeout=120)
        print(f"{group} homed successfully.")

    def move_absolute(self, group, target_mm, wait=True):
        self._check(self._to_rc(self.xps.GroupMoveAbsolute(group, [target_mm], 1)), f"MoveAbsolute {group}")
        if wait:
            self.wait_for_move_end(group)

    def move_relative(self, group, distance_mm):
        self._check(self._to_rc(self.xps.GroupMoveRelative(group, [distance_mm], 1)), f"MoveRelative {group}")
        self.wait_for_move_end(group)
    
    def get_position_mm(self, group):
        ret = self.xps.GroupPositionCurrentGet(group, 1)
        self._check(ret[0], f"GroupPositionCurrentGet {group}")
        return ret[1]

    def wait_for_move_end(self, group, timeout=60.0):
        t0 = time.time()
        while True:
            if time.time() - t0 > timeout:
                raise TimeoutError(f"Wait for move end timed out for {group}.")
            ret = self.xps.GroupStatusGet(group)
            rc, status = self._to_rc(ret), ret[1]
            self._check(rc, f"GroupStatusGet {group}")
            # Status codes 10 through 18 are "Ready from ..." states
            if 10 <= status <= 18:
                return
            time.sleep(0.05)

    def stop_motion(self, group):
        print(f"STOPPING MOTION FOR {group}")
        self._check(self._to_rc(self.xps.GroupMoveAbort(group)), f"GroupMoveAbort {group}")

    def close(self):
        if self.is_connected:
            self.xps.CloseInstrument()
            print("Disconnected from XPS.")
            self.is_connected = False

# ===========================================================================
# DAQ Reader Class
# ===========================================================================
class DAQReader:
    """A wrapper class for reading averaged voltage from an NI-DAQ device."""
    def __init__(self, channel, rate_hz, samples):
        self.channel = channel
        self.rate = rate_hz
        self.samples = samples

    def read_average_voltage(self):
        try:
            with nidaqmx.Task() as task:
                task.ai_channels.add_ai_voltage_chan(self.channel)
                task.timing.cfg_samp_clk_timing(
                    self.rate,
                    sample_mode=nidaqmx.constants.AcquisitionType.FINITE,
                    samps_per_chan=self.samples
                )
                data = task.read(number_of_samples_per_channel=self.samples, timeout=2.0)
                return np.mean(data)
        except Exception as e:
            raise ConnectionError(f"Failed to read from DAQ on {self.channel}. Details: {e}")

# ===========================================================================
# Positioning GUI Class
# ===========================================================================
class PositioningGUI:
    """A Tkinter GUI for manual Z-axis control and starting the optimization."""
    def __init__(self, controller):
        self.controller = controller
        self.automation_started = False
        self.start_z_um = 0.0

        self.root = tk.Tk()
        self.root.title("Z-Axis Manual Positioning (µm)")
        self.root.protocol("WM_DELETE_WINDOW", self._on_closing)

        frame = ttk.Frame(self.root, padding="15")
        frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        self.z_pos_var = tk.StringVar(value=f"Z: {self.start_z_um:8.2f} µm")
        ttk.Label(frame, textvariable=self.z_pos_var, font=("Courier", 14)).grid(row=0, column=0, columnspan=3, sticky=tk.W, pady=(0, 10))

        ttk.Label(frame, text="Step Size (µm):").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.step_var = tk.StringVar(value="100.0")
        ttk.Entry(frame, textvariable=self.step_var, width=12).grid(row=1, column=1, columnspan=2, sticky=tk.W)

        ttk.Button(frame, text="Z + (Up)", command=lambda: self._jog(1)).grid(row=2, column=1, ipady=5)
        ttk.Button(frame, text="Z - (Down)", command=lambda: self._jog(-1)).grid(row=3, column=1, pady=5, ipady=5)

        ttk.Separator(frame, orient='horizontal').grid(row=4, column=0, columnspan=3, sticky='ew', pady=15)

        style = ttk.Style()
        style.configure("Accent.TButton", foreground="white", background="#007ACC", font=('Helvetica', 10, 'bold'))
        style.configure("Stop.TButton", foreground="white", background="#D32F2F", font=('Helvetica', 12, 'bold'))
        
        ttk.Button(frame, text="Start Automated Search From Here", command=self._start_automation, style="Accent.TButton").grid(row=5, column=0, columnspan=3, sticky='ew', ipady=10)
        self.stop_button = ttk.Button(frame, text="EMERGENCY STOP", command=self._emergency_stop, style="Stop.TButton", state=tk.DISABLED)
        self.stop_button.grid(row=6, column=0, columnspan=3, sticky='ew', ipady=10, pady=(10,0))
    
    def _update_position(self):
        current_pos_mm = self.controller.get_position_mm(GROUP_Z)
        self.start_z_um = current_pos_mm * UM_PER_MM
        self.z_pos_var.set(f"Z: {self.start_z_um:8.2f} µm")

    def _jog(self, direction):
        try:
            step_um = float(self.step_var.get())
            self.controller.move_relative(GROUP_Z, direction * step_um / UM_PER_MM)
            self._update_position()
        except ValueError:
            messagebox.showerror("Invalid Input", "Step size must be a number.")
        except Exception as e:
            messagebox.showerror("Motion Error", str(e))

    def _start_automation(self):
        if messagebox.askokcancel("Confirm Start", f"Start automated search from Z = {self.start_z_um:.2f} µm?"):
            self.automation_started = True
            self.root.destroy()

    def _emergency_stop(self):
        print("GUI Stop Button Pressed!")
        stop_flag.set()

    def _on_closing(self):
        if not self.automation_started:
            if messagebox.askokcancel("Quit", "Do you want to exit without searching?"):
                self.root.destroy()

    def run(self):
        self._update_position()
        self.root.mainloop()

# ===========================================================================
# Optimization and Main Execution Logic
# ===========================================================================

def run_optimization(controller, daq, start_z_um):
    """Performs the gradient ascent to find the optimal Z position."""
    print("\n" + "="*50)
    print("Starting Automated Search...")
    print(f"Parameters: Initial Step={INITIAL_STEP_UM}µm, Min Step={MIN_STEP_UM}µm")
    print("="*50)

    positions_um, voltages = [], []
    
    z_current_um = start_z_um
    step_um = INITIAL_STEP_UM
    search_dir = INITIAL_SEARCH_DIRECTION

    # Initial measurement at start position
    controller.move_absolute(GROUP_Z, z_current_um / UM_PER_MM)
    v_current = daq.read_average_voltage()
    
    z_best_um = z_current_um
    v_best = v_current

    positions_um.append(z_current_um)
    voltages.append(v_current)
    print(f"Initial Reading: Pos={z_current_um:8.2f} µm, Voltage={v_current:7.4f} V")

    while step_um > MIN_STEP_UM:
        if stop_flag.is_set():
            print("Emergency stop triggered! Aborting search.")
            break

        z_next_um = z_current_um + search_dir * step_um
        
        # Safety check
        if abs(z_next_um - start_z_um) > MAX_SEARCH_RANGE_UM:
            print(f"Search exceeded safety range of {MAX_SEARCH_RANGE_UM} µm. Stopping.")
            break

        controller.move_absolute(GROUP_Z, z_next_um / UM_PER_MM)
        v_next = daq.read_average_voltage()
        
        positions_um.append(z_next_um)
        voltages.append(v_next)
        
        print(f"  Step={step_um:5.2f}µm, Pos={z_next_um:8.2f} µm, Voltage={v_next:7.4f} V")

        if v_next > v_best:
            # Improvement found, keep going in the same direction
            v_best, z_best_um = v_next, z_next_um
            z_current_um = z_next_um
        else:
            # Passed the peak, reverse direction and reduce step size
            print("  Peak passed. Reversing direction and reducing step size.")
            search_dir *= -1
            step_um *= STEP_REDUCTION_FACTOR
            # Go back to the best known position to start the finer search
            z_current_um = z_best_um
            controller.move_absolute(GROUP_Z, z_best_um / UM_PER_MM)
    
    print("="*50)
    print("Search Finished!")
    print(f"Optimal Position Found: Z = {z_best_um:.3f} µm")
    print(f"Maximum Voltage: V = {v_best:.4f} V")
    print("="*50)
    
    # Move to the best position found
    print(f"Moving to optimal position: {z_best_um:.3f} µm...")
    controller.move_absolute(GROUP_Z, z_best_um / UM_PER_MM)

    return positions_um, voltages, z_best_um

def plot_results(positions, voltages, optimum_z):
    """Plots the Voltage vs. Position data."""
    optimum_v = max(voltages)
    
    plt.figure(figsize=(10, 6))
    plt.plot(positions, voltages, 'o-', label='Measured Data', markersize=4, c='royalblue')
    plt.axvline(x=optimum_z, color='r', linestyle='--', label=f'Optimal Z = {optimum_z:.2f} µm')
    plt.scatter([optimum_z], [optimum_v], s=100, c='red', zorder=5, label=f'Max Voltage = {optimum_v:.3f} V')
    
    plt.title('DAQ Voltage vs. Z-Axis Position')
    plt.xlabel('Z Position (µm)')
    plt.ylabel('Voltage (V)')
    plt.legend()
    plt.grid(True, linestyle=':')
    plt.tight_layout()
    print("Displaying results plot...")
    plt.show()

def main():
    controller = None
    try:
        # --- Initialization ---
        controller = XPSController(XPS_IP, XPS_PORT, XPS_TIMEOUT_MS)
        daq = DAQReader(DAQ_CHANNEL, DAQ_SAMPLING_RATE_HZ, DAQ_SAMPLES_PER_READ)
        
        vel_z_mm = VEL_Z_UM / UM_PER_MM
        acc_z_mm = ACC_Z_UM / UM_PER_MM
        
        controller.home_axis(GROUP_Z, POS_Z, vel_z_mm, acc_z_mm)
        
        # --- Manual Positioning GUI ---
        gui = PositioningGUI(controller)
        gui.root.deiconify() # Ensure window is visible
        
        # The main thread runs the GUI. A separate thread will monitor the stop flag.
        # This setup is simple. For a fully responsive GUI during the scan, the
        # optimization logic would need to run in the separate thread.
        gui.run()

        if not gui.automation_started:
            print("GUI closed without starting the scan. Exiting.")
            return

        # Disable GUI interaction and enable stop button for the next phase
        # (This is conceptual as the GUI is destroyed. A more complex app would disable widgets)
        print("Manual positioning complete. Handing over to automated search.")
        
        # --- Automated Search ---
        # The stop flag can now be set by a (hypothetical) running GUI or other input
        # For this script, the stop button is tied to the GUI's lifecycle.
        # A more robust implementation would keep the GUI alive but disabled.
        
        search_thread = threading.Thread(
            target=run_optimization,
            args=(controller, daq, gui.start_z_um)
        )
        # For simplicity, we directly call the function here.
        # To make a STOP button work after closing the first GUI, a second status window
        # would need to be created.
        
        positions, voltages, optimum_z = run_optimization(controller, daq, gui.start_z_um)

        # --- Results and Cleanup ---
        if positions:
            plot_results(positions, voltages, optimum_z)

    except (RuntimeError, TimeoutError, ConnectionError) as e:
        print(f"\nAN ERROR OCCURRED: {e}")
        traceback.print_exc()
        if controller:
            print("Attempting to stop all motion due to error...")
            controller.stop_motion(GROUP_Z)
    finally:
        if controller:
            controller.close()
        input("Press Enter to exit...")

if __name__ == "__main__":
    main()