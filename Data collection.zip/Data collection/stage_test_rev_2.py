import clr
import time
import traceback
import tkinter as tk
from tkinter import ttk, messagebox

# ---------------------------------------------------------------------------
# Python script to connect to Newport XPS-D, home axes, and allow a user
# to position the stage via a GUI. The script performs continuous line scans
# with all user-facing units in micrometers (µm).
#
# Revision 7: Corrected jog button direction bug.
# ---------------------------------------------------------------------------

# 1) Load the XPS .NET assembly
try:
    clr.AddReference(
        r"C:\Windows\Microsoft.NET\assembly\GAC_64\Newport.XPS.CommandInterface"
        r"\v4.0_2.3.1.0__9a267756cf640dcf\Newport.XPS.CommandInterface.dll"
    )
    from CommandInterfaceXPS import XPS
except Exception as e:
    print("FATAL ERROR: Could not load Newport XPS .NET assembly.")
    print("Please check the DLL path in the script.")
    print(f"Details: {e}")
    input("Press Enter to exit...")
    exit()

# Conversion constant
UM_PER_MM = 1000.0

# -------------------------
# CONNECTION & TIMEOUT
# -------------------------
IP = "192.168.0.254"
PORT = 5001
TIMEOUT_MS = 100000

# -------------------------
# SCAN & MOTION PARAMETERS (ALL VALUES IN MICROMETERS)
# -------------------------
GROUP_X = "Group1"
GROUP_Y = "Group2"
POS_X = f"{GROUP_X}.Pos"
POS_Y = f"{GROUP_Y}.Pos"

# Scan dimensions relative to the start point set in the GUI
SCAN_WIDTH_UM = 10000.0  # 10 mm
SCAN_HEIGHT_UM = 10000.0 # 10 mm

# Spacing between continuous scan lines
LINE_SPACING_X_UM = 10.0 # Used when SCAN_AXIS is 'Y'
LINE_SPACING_Y_UM = 10.0 # Used when SCAN_AXIS is 'X'

# Velocity (µm/s) and acceleration (µm/s²)
VEL_X_UM, ACC_X_UM = 100.0, 2000.0 # 10 mm/s, 20 mm/s^2
VEL_Y_UM, ACC_Y_UM = 100.0, 2000.0 # 10 mm/s, 20 mm/s^2

# Choose 'X' for continuous scans along the X-axis, or 'Y' along the Y-axis
SCAN_AXIS = 'X'

# ===========================================================================
# XPS Controller Class
# ===========================================================================

class XPSController:
    """A wrapper class for the XPS hardware controller. All methods expect units in mm."""
    def __init__(self, ip, port, timeout):
        self.xps = XPS()
        self.is_connected = False
        rc = self._to_rc(self.xps.OpenInstrument(ip, port, timeout))
        self._check(rc, "OpenInstrument")
        print(f"Connected to XPS at {ip}:{port}")
        self.is_connected = True

    def _to_rc(self, ret):
        return ret if isinstance(ret, int) else ret[0]

    def _check(self, rc, name):
        if rc != 0:
            error_string_tuple = self.xps.ErrorStringGet(rc)
            raise RuntimeError(f"{name} failed (code={rc}): {error_string_tuple[1]}")

    def home_axis(self, group, pos, vel_mm, acc_mm):
        print(f"Homing {group}…")
        self._check(self._to_rc(self.xps.GroupInitialize(group)), f"GroupInitialize {group}")
        self._check(self._to_rc(self.xps.PositionerSGammaParametersSet(pos, vel_mm, acc_mm, 0.001, 0.005)), f"SGammaSet {pos}")
        self._check(self._to_rc(self.xps.GroupHomeSearch(group)), f"GroupHomeSearch {group}")
        self.wait_for_status(group, 11, timeout=60)
        print(f"{group} homed.")

    def set_motion_profile(self, group, pos, vel_mm, acc_mm):
        self._check(self._to_rc(self.xps.PositionerSGammaParametersSet(pos, vel_mm, acc_mm, 0.001, 0.005)), f"SGammaSet {pos}")
        print(f"Motion profile set for {group} (V={vel_mm} mm/s, A={acc_mm} mm/s^2).")

    def move_absolute(self, group, target_mm):
        self._check(self._to_rc(self.xps.GroupMoveAbsolute(group, [target_mm], 1)), f"MoveAbsolute {group} to {target_mm:.4f} mm")
        self.wait_for_status(group, 12)

    def move_relative(self, group, distance_mm):
        self._check(self._to_rc(self.xps.GroupMoveRelative(group, [distance_mm], 1)), f"MoveRelative {group}")
        self.wait_for_status(group, 12)

    def wait_for_status(self, group, desired_status, timeout=30.0):
        t0 = time.time()
        while True:
            ret = self.xps.GroupStatusGet(group)
            rc, status = self._to_rc(ret), ret[1]
            self._check(rc, f"GroupStatusGet {group}")
            if status == desired_status:
                return
            if time.time() - t0 > timeout:
                raise TimeoutError(f"{group} did not reach status {desired_status} in time.")
            time.sleep(0.05)

    def close(self):
        if self.is_connected:
            self.xps.CloseInstrument()
            print("Disconnected from XPS.")
            self.is_connected = False

# ===========================================================================
# Positioning GUI Class
# ===========================================================================

class PositioningGUI:
    """A Tkinter GUI that tracks position internally in micrometers."""
    def __init__(self, controller):
        self.controller = controller
        self.scan_started = False
        self.tracked_x_um = 0.0
        self.tracked_y_um = 0.0
        self.start_x_um = 0.0
        self.start_y_um = 0.0

        self.root = tk.Tk()
        self.root.title("XPS Stage Positioning (µm)")
        self.root.protocol("WM_DELETE_WINDOW", self._on_closing)

        frame = ttk.Frame(self.root, padding="10")
        frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        self.x_pos_var = tk.StringVar(value=f"X: {self.tracked_x_um:9.1f} µm")
        self.y_pos_var = tk.StringVar(value=f"Y: {self.tracked_y_um:9.1f} µm")
        ttk.Label(frame, textvariable=self.x_pos_var, font=("Courier", 12)).grid(row=0, column=0, columnspan=3, sticky=tk.W)
        ttk.Label(frame, textvariable=self.y_pos_var, font=("Courier", 12)).grid(row=1, column=0, columnspan=3, sticky=tk.W)

        ttk.Label(frame, text="Step Size (µm):").grid(row=2, column=0, sticky=tk.W, pady=10)
        self.step_var = tk.StringVar(value="1000.0")
        ttk.Entry(frame, textvariable=self.step_var, width=10).grid(row=2, column=1, columnspan=2, sticky=tk.W)

        ttk.Button(frame, text="Y+", command=lambda: self._jog(GROUP_Y, 1)).grid(row=3, column=1)
        ttk.Button(frame, text="X-", command=lambda: self._jog(GROUP_X, -1)).grid(row=4, column=0)
        ttk.Button(frame, text="X+", command=lambda: self._jog(GROUP_X, 1)).grid(row=4, column=2)
        ttk.Button(frame, text="Y-", command=lambda: self._jog(GROUP_Y, -1)).grid(row=5, column=1, pady=5)
        
        ttk.Separator(frame, orient='horizontal').grid(row=6, column=0, columnspan=3, sticky='ew', pady=10)
        ttk.Button(frame, text="Start Scan at Current Position", command=self._start_scan, style="Accent.TButton").grid(row=7, column=0, columnspan=3, sticky='ew', ipady=5)
        
        style = ttk.Style()
        style.configure("Accent.TButton", foreground="white", background="green", font=('calibri', 10, 'bold'))

    def _jog(self, group, direction):
        try:
            step_um = float(self.step_var.get())
            step_mm = step_um / UM_PER_MM
            
            # ***** THIS IS THE CORRECTED LINE *****
            # The 'direction' must be multiplied here to move the actual stage
            self.controller.move_relative(group, direction * step_mm)

            if group == GROUP_X:
                self.tracked_x_um += direction * step_um
                self.x_pos_var.set(f"X: {self.tracked_x_um:9.1f} µm")
            else:
                self.tracked_y_um += direction * step_um
                self.y_pos_var.set(f"Y: {self.tracked_y_um:9.1f} µm")

        except ValueError:
            messagebox.showerror("Invalid Input", "Step size must be a number.")
        except Exception as e:
            messagebox.showerror("Motion Error", str(e))

    def _start_scan(self):
        self.start_x_um = self.tracked_x_um
        self.start_y_um = self.tracked_y_um
        print(f"Scan start position set from tracked location ({self.start_x_um:.1f}, {self.start_y_um:.1f}) µm.")
        self.scan_started = True
        self.root.destroy()
        print("GUI closed. Starting scan...")

    def _on_closing(self):
        if messagebox.askokcancel("Quit", "Do you want to exit without scanning?"):
            self.scan_started = False
            self.root.destroy()

    def run(self):
        self.root.mainloop()

# ===========================================================================
# Main Execution Logic
# ===========================================================================

def main():
    controller = None
    try:
        controller = XPSController(IP, PORT, TIMEOUT_MS)
        # Convert µm parameters to mm for hardware setup
        vel_x_mm = VEL_X_UM / UM_PER_MM
        acc_x_mm = ACC_X_UM / UM_PER_MM
        vel_y_mm = VEL_Y_UM / UM_PER_MM
        acc_y_mm = ACC_Y_UM / UM_PER_MM

        controller.home_axis(GROUP_X, POS_X, vel_x_mm, acc_x_mm)
        controller.home_axis(GROUP_Y, POS_Y, vel_y_mm, acc_y_mm)
        controller.set_motion_profile(GROUP_X, POS_X, vel_x_mm, acc_x_mm)
        controller.set_motion_profile(GROUP_Y, POS_Y, vel_y_mm, acc_y_mm)
        
        gui = PositioningGUI(controller)
        gui.run()

        if not gui.scan_started:
            print("GUI was closed without starting the scan. Exiting.")
            return

        start_x_um, start_y_um = gui.start_x_um, gui.start_y_um

        print("-" * 30)
        print(f"Starting continuous {SCAN_AXIS}-axis scan from ({start_x_um:.1f}, {start_y_um:.1f}) µm")
        
        # Move to the absolute starting corner of the scan area
        print("Moving to initial scan position...")
        controller.move_absolute(GROUP_X, start_x_um / UM_PER_MM)
        controller.move_absolute(GROUP_Y, start_y_um / UM_PER_MM)

        if SCAN_AXIS == 'X':
            # Generate the list of Y positions for each scan line
            num_lines = int(SCAN_HEIGHT_UM / LINE_SPACING_Y_UM) + 1
            y_lines_um = [start_y_um + i * LINE_SPACING_Y_UM for i in range(num_lines)]
            x_start_um, x_end_um = start_x_um, start_x_um + SCAN_WIDTH_UM

            for i, y_pos_um in enumerate(y_lines_um):
                # Move to the Y position for the current line
                controller.move_absolute(GROUP_Y, y_pos_um / UM_PER_MM)
                
                # Determine scan direction for serpentine motion
                scan_start_x_um = x_start_um if (i % 2) == 0 else x_end_um
                scan_end_x_um = x_end_um if (i % 2) == 0 else x_start_um
                
                # Ensure we are at the start of the line before continuous scan
                controller.move_absolute(GROUP_X, scan_start_x_um / UM_PER_MM)

                # Execute the continuous scan
                print(f"  Scanning line {i+1}/{num_lines} at Y={y_pos_um:.1f} µm from X={scan_start_x_um:.1f} to {scan_end_x_um:.1f} µm")
                controller.move_absolute(GROUP_X, scan_end_x_um / UM_PER_MM)

        elif SCAN_AXIS == 'Y':
            # Generate the list of X positions for each scan line
            num_lines = int(SCAN_WIDTH_UM / LINE_SPACING_X_UM) + 1
            x_lines_um = [start_x_um + i * LINE_SPACING_X_UM for i in range(num_lines)]
            y_start_um, y_end_um = start_y_um, start_y_um + SCAN_HEIGHT_UM

            for i, x_pos_um in enumerate(x_lines_um):
                # Move to the X position for the current line
                controller.move_absolute(GROUP_X, x_pos_um / UM_PER_MM)

                # Determine scan direction for serpentine motion
                scan_start_y_um = y_start_um if (i % 2) == 0 else y_end_um
                scan_end_y_um = y_end_um if (i % 2) == 0 else y_start_um
                
                # Ensure we are at the start of the line before continuous scan
                controller.move_absolute(GROUP_Y, scan_start_y_um / UM_PER_MM)
                
                # Execute the continuous scan
                print(f"  Scanning line {i+1}/{num_lines} at X={x_pos_um:.1f} µm from Y={scan_start_y_um:.1f} to {scan_end_y_um:.1f} µm")
                controller.move_absolute(GROUP_Y, scan_end_y_um / UM_PER_MM)

        print("\nScan complete.")
        print(f"Returning to start position ({start_x_um:.1f}, {start_y_um:.1f}) µm.")
        controller.move_absolute(GROUP_X, start_x_um / UM_PER_MM)
        controller.move_absolute(GROUP_Y, start_y_um / UM_PER_MM)

    except (RuntimeError, TimeoutError, ConnectionError) as e:
        print(f"\nAN ERROR OCCURRED: {e}")
        traceback.print_exc()
    finally:
        if controller:
            controller.close()
        input("Press Enter to exit...")

if __name__ == "__main__":
    main()