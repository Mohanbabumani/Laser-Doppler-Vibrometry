import clr
import time
import traceback

# ---------------------------------------------------------------------------
# Python script to connect to Newport XPS-D, home axes, and perform either 
# an X‐oriented or Y‐oriented serpentine raster (line) scan. All parameters 
# and choice of scan axis are hard‐coded below.
# ---------------------------------------------------------------------------

# 1) Load the XPS .NET assembly
clr.AddReference(
    r"C:\Windows\Microsoft.NET\assembly\GAC_64\Newport.XPS.CommandInterface"
    r"\v4.0_2.3.1.0__9a267756cf640dcf\Newport.XPS.CommandInterface.dll"
)
from CommandInterfaceXPS import XPS

# -------------------------
# CONNECTION & TIMEOUT
# -------------------------
IP         = "192.168.0.254"
PORT       = 5001
TIMEOUT_MS = 60000

# -------------------------
# SCAN & MOTION PARAMETERS
# -------------------------
GROUP_X    = "Group1"
GROUP_Y    = "Group2"

# bounds and step in mm
X_START, X_END, X_STEP = 0.0, 10.0, 1 
Y_START, Y_END, Y_STEP = 0.0,  10.0, 1

# velocity (mm/s) and acceleration (mm/s²)
VEL_X, ACC_X = 10.0, 20.0
VEL_Y, ACC_Y = 10.0, 20.0

POSITION_TOL = 1e-3   # mm, skip tiny moves

# Choose 'X' to scan lines along X (vary X for each Y), or 'Y' to scan along Y
SCAN_AXIS = 'Y'  # or 'Y'

# === UTILITY FUNCTIONS ===

def to_rc(ret):
    return ret if isinstance(ret, int) else ret[0]

def check(rc, name):
    if rc != 0:
        raise RuntimeError(f"{name} failed (code={rc})")

def wait_status(group, desired, timeout=30.0):
    """Poll GroupStatusGet until status == desired."""
    t0 = time.time()
    while True:
        ret = xps.GroupStatusGet(group)
        rc, status = to_rc(ret), ret[1]
        check(rc, f"GroupStatusGet {group}")
        if status == desired:
            return
        if time.time() - t0 > timeout:
            raise TimeoutError(f"{group} did not reach status {desired}")
        time.sleep(0.05)

# === CONNECT & HOME ===

xps = XPS()
rc = to_rc(xps.OpenInstrument(IP, PORT, TIMEOUT_MS))
check(rc, "OpenInstrument")
rc = to_rc(xps.SetTimeout(TIMEOUT_MS, TIMEOUT_MS))
check(rc, "SetTimeout")
print(f"Connected to XPS at {IP}:{PORT} (timeout={TIMEOUT_MS} ms)")

def home_axis(group, vel, acc):
    print(f"Homing {group}…")
    rc = to_rc(xps.GroupInitialize(group))
    check(rc, f"GroupInitialize {group}")
    full = f"{group}.Pos"
    rc = to_rc(xps.PositionerSGammaParametersSet(full, vel, acc, 0.001, 0.005))
    check(rc, f"PositionerSGammaParametersSet {full}")
    rc = to_rc(xps.GroupHomeSearch(group))
    check(rc, f"GroupHomeSearch {group}")
    wait_status(group, 11)
    print(f"{group} homed.")

home_axis(GROUP_X, VEL_X, ACC_X)
home_axis(GROUP_Y, VEL_Y, ACC_Y)

# === MOTION PROFILE ===

def set_profile(group, vel, acc):
    full = f"{group}.Pos"
    rc = to_rc(xps.PositionerSGammaParametersSet(full, vel, acc, 0.001, 0.005))
    check(rc, f"PositionerSGammaParametersSet {full}")

set_profile(GROUP_X, VEL_X, ACC_X)
set_profile(GROUP_Y, VEL_Y, ACC_Y)

# === MOVE HELPER ===

def move_to(group, target):
    rc = to_rc(xps.GroupMoveAbsolute(group, [target], 1))
    check(rc, f"GroupMoveAbsolute {group}→{target}")
    wait_status(group, 12)

# === SCAN LOGIC ===

# Build vectors
xs = [X_START + i*X_STEP for i in range(int((X_END - X_START)/X_STEP) + 1)]
ys = [Y_START + j*Y_STEP for j in range(int((Y_END - Y_START)/Y_STEP) + 1)]

print(f"Starting {'X' if SCAN_AXIS=='X' else 'Y'}-axis scans…")

if SCAN_AXIS == 'X':
    # For each Y row, scan along X
    move_to(GROUP_X, X_START)
    move_to(GROUP_Y, Y_START)
    for row, y in enumerate(ys):
        move_to(GROUP_Y, y)
        seq = xs if (row % 2)==0 else list(reversed(xs))
        for x in seq:
            move_to(GROUP_X, x)
            print(f"At X={x:.3f}, Y={y:.3f}")
elif SCAN_AXIS == 'Y':
    # For each X column, scan along Y
    move_to(GROUP_X, X_START)
    move_to(GROUP_Y, Y_START)
    for col, x in enumerate(xs):
        move_to(GROUP_X, x)
        seq = ys if (col % 2)==0 else list(reversed(ys))
        for y in seq:
            move_to(GROUP_Y, y)
            print(f"At X={x:.3f}, Y={y:.3f}")
else:
    raise ValueError("SCAN_AXIS must be 'X' or 'Y'")

print("Scan complete.")

# === CLEANUP ===
try:
    xps.CloseInstrument()
except:
    pass
